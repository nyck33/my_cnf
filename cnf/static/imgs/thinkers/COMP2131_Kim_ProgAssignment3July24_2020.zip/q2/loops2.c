/*
Get assembly of 4 loops, check for similarities and differences
gcc -O1 -S loops.c
Flag -O1 "capital-O 1" for optimization for code size and execution time
https://www.rapidtables.com/code/linux/gcc/gcc-o.html
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

void forLoop(int* arr, int len){
    int sum=0;
    for(int i=0; i<len; i++){
        sum+=arr[i];
    }
    printf("\nForLoop Sum from %d to %d is %d\n", arr[0], arr[len-1], sum );
}
void whileLoop(int *arr, int len){
    int sum=0, count=0;
    while(count<len){
        sum+=arr[count];
        count++;
    }
    printf("\nwhileLoop Sum from %d to %d is %d\n", arr[0], arr[len-1], sum );
}
void doWhileLoop(int *arr, int len){
    int sum=0, count=0;
    do{
        sum+=arr[count];
        count++;
    }while(count<len);
    printf("\ndowWhileLoop Sum from %d to %d is %d\n", arr[0], arr[len-1], sum );
}
void gotoLoop(int* arr, int len){
    int sum=0, count=0;
    
    goto addition;

    addition:
        if(count < len){
            sum+=arr[count];
            count++;
            goto addition;
        }

    printf("\ngotoLoop Sum from %d to %d is %d\n", arr[0], arr[len-1], sum );
}

int main(int argc, char* argv[]){
    int start = 0;
    int end = 2;
    /*
    if(argc>0){
        start = atoi(argv[1]);
        end = atoi(argv[2]); 
    } 
    else{
        printf("Usage ./program start end");
    }
    */
    //+1 for inclusive
    int num_elements = end-start+1;
    int *arr = malloc(sizeof *arr * (num_elements));
    if(!arr){
        printf("malloc error arr main\n");
        exit(1);
    }
    //fill arr
    for(int i=0; i < num_elements; i++){
        arr[i] = start + i;
    }

    forLoop(arr, num_elements);
    whileLoop(arr, num_elements);
    doWhileLoop(arr, num_elements);
    gotoLoop(arr, num_elements);

    free(arr);

    return 0;
}   