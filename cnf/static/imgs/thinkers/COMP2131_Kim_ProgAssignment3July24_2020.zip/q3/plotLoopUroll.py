import matplotlib.pyplot as plt
import datetime


normal, unroll, no_loop, unroll_inc = [], [], [],[]

# files
for line in open('normal_loop.txt', 'r'):
    val = float(line)
    normal.append(val)

for line in open('unroll_loop.txt'):
    val = float(line)
    unroll.append(val)

for line in open('no_loop.txt'):
    val = float(line)
    no_loop.append(val)

for line in open('unroll_inc.txt'):
    val = float(line)
    unroll_inc.append(val)


#X-axis array
X = []
for i in range(len(normal)):
    X.append(i)

lines = [normal, unroll, no_loop, unroll_inc]
colors = ['r', 'g', 'b', 'brown']
labels = ['no unroll', 'unroll', 'no loop', 'unroll++']

for i, c, l in zip(lines,colors, labels):
    plt.plot(X,i,c,label='l')
    plt.legend(labels)
fig = plt.gcf()
plt.show()

curr_date = datetime.datetime.utcnow()
fig.savefig(f'unroll_{curr_date}.png')
