/*q3 loop unrolling
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    FILE *f_normal = fopen("normal_loop.txt", "w");
    FILE *f_unroll = fopen("unroll_loop.txt", "w");
    FILE *f_no_loop = fopen("no_loop.txt", "w");
    FILE *f_unroll_inc = fopen("unroll_inc.txt", "w");
    
    const size_t ARR_SIZE = 1000;
    //for clock speed
    clock_t start, end;
    //hold cpu time
    long double cpu_time_used, unroll_cpu_time_used, no_loop_time, unroll_inc;
    //arrays to hold run times
    //long double normal_times[ARR_SIZE];
    //long double unroll_times[ARR_SIZE];
    //long double no_loop_times[ARR_SIZE];
    //preset counters outside loops
    size_t i=0, j=0;
    //arr
    int *arr = malloc(sizeof *arr * 50);
    //fill array
    for(j =0; j<50; j++){
        arr[j] = j;
        //printf("\narr[%d]: %d\n", j, arr[j]);
    }
    //vars for unroll
    int sum=0, sum1=0, sum2=0, sum3=0, sum4=0, sum5=0, sum6=0, sum7=0, sum8=0, sum9=0, sum_ten=0;
    size_t count = 0;
    
    while(1){
        start = clock();
        for(i =0; i< 50; i++){
            //printf("\ni: %d", i);
            sum += arr[i];
        }
        end = clock();
        //time_used = end-start;
        cpu_time_used = ((long double)(end-start)*1000) / CLOCKS_PER_SEC;
        //printf("\nNo unroll sum: %d time: %Lf ", sum, cpu_time_used);
        //normal_times[count] = cpu_time_used;
        fprintf(f_normal, "%Lf\n", cpu_time_used);
        /*-----------------------------------------------------------------------------------------*/
        start=clock();
        for(i =0; i< 50; i+=10){
            sum1 += arr[i];
            sum2 += arr[i+1];
            //printf("second: %d", second);
            sum3 += arr[i+2];
            sum4 += arr[i+3];
            sum5 += arr[i+4];
            sum6 += arr[i+5];
            sum7 += arr[i+6];
            sum8 += arr[i+7];
            sum9 += arr[i+8];
            sum_ten += arr[i+9];        
        }
        sum = sum1 + sum2 + sum3 + sum4 + sum5 + sum6 + sum7 + sum8 + sum9 + sum_ten;
        end = clock();
        unroll_cpu_time_used = ((long double)(end-start)*1000) /CLOCKS_PER_SEC;
        //printf("\nUnroll sum: %d, time: %Lf", sum, unroll_cpu_time_used);
        //unroll_times[count] = unroll_cpu_time_used;
        fprintf(f_unroll, "%Lf\n", unroll_cpu_time_used);
        /*-----------------------------------------------------------------------------------*/
        sum = 0;
        start = clock();
        for(i =0; i< 50; i++){
            sum += arr[i];
            i++;
            sum += arr[i];
            i++;
            sum += arr[i];
            i++;
            sum += arr[i];
            i++;
            sum += arr[i];
            i++;
            sum += arr[i];
            i++;
            sum += arr[i];
            i++;
            sum += arr[i];
            i++;
            sum += arr[i];
            i++;
            sum += arr[i];
        }
        end=clock();
        unroll_inc = ((long double)(end-start)*1000) /CLOCKS_PER_SEC;
        //printf("\nUnroll sum: %d, time: %Lf", sum, unroll_cpu_time_used);
        //unroll_times[count] = unroll_cpu_time_used;
        fprintf(f_unroll_inc, "%Lf\n", unroll_inc);
        /*----------------------------------------------------------------------------------*/
        start = clock();
        sum = arr[0] + arr[1] + arr[2] + arr[3] + arr[4] + arr[5] + arr[6] + arr[7] + arr[8] + arr[9] 
        + arr[10] + arr[11] + arr[12] + arr[13] + arr[14] + arr[15] + arr[16] + arr[17] + arr[18] + arr[19] 
        + arr[20] + arr[21] + arr[22] + arr[23] + arr[24] + arr[25] + arr[26] + arr[27] + arr[28] + arr[29] 
        + arr[30] + arr[31] + arr[32] + arr[33] + arr[34] + arr[35] + arr[36] + arr[37] + arr[38] + arr[39] 
        + arr[40] + arr[41] + arr[42] + arr[43] + arr[44] + arr[45] + arr[46] + arr[47] + arr[48] + arr[49]
        + arr[50]; 
        end = clock();
        no_loop_time = ((long double)(end-start)*1000) / CLOCKS_PER_SEC;
        //no_loop_times[count] = no_loop_time;
        //printf("\nNo loop sum: %d, time: %Lf", sum, no_loop_time);
        fprintf(f_no_loop, "%Lf\n", no_loop_time);
        count++;
        if(count>=ARR_SIZE){
            break;
        }
    }

    //fwrite(normal_times, sizeof(int), sizeof(normal_times), f_normal);
    //fwrite(unroll_times, sizeof(int), sizeof(unroll_times), f_unroll);
    //fwrite(no_loop_times, sizeof(int), sizeof(no_loop_times), f_no_loop);
    fclose(f_normal);
    fclose(f_unroll);
    fclose(f_no_loop);
    fclose(f_unroll_inc);
    free(arr);
    return 0;
}